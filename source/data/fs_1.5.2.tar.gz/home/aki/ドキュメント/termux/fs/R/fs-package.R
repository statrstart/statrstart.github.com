#' @description
#' \ifelse{html}{
#' \out{
#' <a href="https://lifecycle.r-lib.org/articles/stages.html#maturing">
#'   <img src="https://img.shields.io/badge/lifecycle-maturing-blue.svg" alt="Maturing lifecycle">
#' </a>
#' }
#' }{
#' \url{https://lifecycle.r-lib.org/articles/stages.html#maturing}
#' }
#' @keywords internal
"_PACKAGE"
