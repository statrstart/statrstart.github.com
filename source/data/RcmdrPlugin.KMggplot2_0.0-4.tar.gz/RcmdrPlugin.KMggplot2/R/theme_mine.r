theme_mine <- function(base_size = 11, base_family = "",
                           base_line_size = base_size / 22,
                           base_rect_size = base_size / 22) {
  half_line <- base_size / 2
  # Starts with theme_bw and then modify some parts
  # = replace all greys with pure black or white
  theme_bw(
    base_size = base_size,
    base_family = base_family,
    base_line_size = base_line_size,
    base_rect_size = base_rect_size
  ) %+replace%
    theme(
      # black text and ticks on the axes
   axis.line = element_line(),
      axis.text        = element_text(colour = "black", size = rel(0.8)),
      axis.ticks       = element_line(colour = "black", size = rel(0.5)),
      # NB: match the *visual* thickness of axis ticks to the panel border
      #     0.5 clipped looks like 0.25
      # pure black panel border and grid lines, but thinner
      panel.border = element_blank(), 
      panel.grid       = element_line(colour = "black"),
      panel.grid.major = element_line(size = rel(0.1)),
      panel.grid.minor = element_line(size = rel(0.05)),
      # strips with black background and white text
      strip.background = element_rect(fill = "grey90", colour = "black"),
      strip.text       = element_text(
                           colour = "black",
                           size = rel(0.8),
                           margin = margin(0.8 * half_line, 0.8 * half_line, 0.8 * half_line, 0.8 * half_line)
                         ),
      complete = TRUE
    )
}
