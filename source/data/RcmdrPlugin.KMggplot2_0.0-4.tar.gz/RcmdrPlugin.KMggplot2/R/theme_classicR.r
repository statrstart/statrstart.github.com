
theme_classicR <- function(base_size = 11, base_family = "",
                          base_line_size = base_size / 22,
                          base_rect_size = base_size / 22) {
  theme_bw(
    base_size = base_size,
    base_family = base_family,
    base_line_size = base_line_size,
    base_rect_size = base_rect_size
  ) %+replace%
    theme(
      # no background and no grid
      panel.border     = element_blank(),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      # show axes
      axis.line      = element_line(colour = "black", size = rel(1)),
      # match legend key to panel.background
#      legend.key       = element_blank(),
# legend:left
 legend.position=c(0.8,0.97),
 legend.justification=c(0,1),
 legend.background = element_rect(fill = "white", colour = "black",size =0.2),
 legend.margin=margin(5,6,5,8),
      # simple, black and white strips
      strip.background = element_rect(fill = "white", colour = "black", size = rel(2)),
      # NB: size is 1 but clipped, it looks like the 0.5 of the axes
      complete = TRUE
    )
}
