base_theme <- theme(
  plot.margin = unit(rep(1, 4), "cm"),
  plot.title = element_text(size = 24, 
                            face = "bold",
                            color = "#22292F", 
                            margin = margin(b = 8)),
  plot.subtitle = element_text(size = 16, 
                               lineheight = 1.1,
                               color = "#22292F",
                               margin = margin(b = 25)),
  plot.caption = element_text(size = 12,
                              margin = margin(t = 25), 
                              color = "#3D4852"),
  axis.title.x = element_text(margin = margin(t = 15)),
  axis.title.y = element_text(margin = margin(r = 15)),
  axis.text = element_text(color = "#22292F")
) 


changecolor <- function(fill= "gray55",colour="black",size=0.25) {
# default : fill="grey35" , colour="NA" ,size=0.5
	barcolor = paste0("update_geom_defaults('bar',list(fill = '",fill,"',colour='",colour,"',size=",size,"))")
	colcolor = paste0("update_geom_defaults('col',list(fill = '",fill,"',colour='",colour,"',size=",size,"))")
	eval(parse(text = barcolor))
	eval(parse(text = colcolor))
}

# 指数表記
exponent_10 <- function(x) {
  ifelse(x==0,"0" ,parse(text= gsub("^1\\%\\*\\%","",gsub("\\^\\+","\\^",gsub("e", "%*%10^", scales::scientific_format()(x)))) ) )
}

#packageVersion("scales")
#[1] ‘1.1.1.9000’
#library(scales)
#demo_log10(c(1, 1e5), labels = label_log())

# 縦書き
tate <- function(x){
	x<-as.vector(x)  
	for(i in 1:length(x)){
		xx<-chartr("ー", "｜",x[i])
		xx<-unlist(strsplit(xx,""))
	x[i]<-paste(xx,collapse= "\n")
	}
return(x)
}



#par(mar=c(4,4,2,1),mgp=c(2,0.5,0))
# scale : comma 
plotts <- function (x , xlab="",ylab="",main="",col="black",lwd=1.2,tck= -0.016 ,units="", scale="") {
		require(scales)
		require(Hmisc)
		plot.ts(x , plot.type="single" , xlab=xlab , ylab=ylab , yaxt="n" , col=col , bty="n" , lwd=lwd , tck=tck)

		if (scale!=""){
			axis(2,at=axTicks(2),labels= eval(parse(text=scale))(axTicks(2)),las=1,tck=tck)
		}else{
			axis(2,at=axTicks(2),labels=axTicks(2),las=1,tck=tck)
		}
		minor.tick(nx=2,ny=2,x.args= list(tck=tck/2),y.args = list(tck=tck/2))
		if (units!=""){
			text(x=par("usr")[1],y=par("usr")[4],labels=paste0("（",units,"）"),xpd=T,pos=2)
		}
		box(bty="l",lwd=2.5)
		title(main)
}


#- 年次
# ts(x,start=c(year) , freq = 1)
#plotts(discoveries,units="件")

#- 四半期
# ts(x,start=c(year,quarter) , freq = 4)
#plotts(austres,units="千人",scale="comma")

#- 月次
# ts(x,start=c(year,month) , freq = 12)
#plotts(USAccDeaths,units="人",scale="comma",tck=0.016)


# long -> wide
# d<- with(nhkC,tapply(各地の感染者数_累計,list(as.Date(日付),都道府県名),function(x) x))

# options(scipen=100) 
# ggplot_build(p)$data
# scales::show_col(hue_pal()(4))
# scales::shape_pal()

#library(ggpmisc)
#g <- g + stat_poly_eq(formula = y~x,
#	aes(label = paste('atop(',paste(stat(eq.label),	sep = '~~~'),',',
#				paste('R~`=`~',round(cor(x,y),2),'~~~',stat(adj.rr.label),sep = ''),
#				')',sep = '')),
#	label.x = 'left',label.y = 'top',parse = TRUE)
#
