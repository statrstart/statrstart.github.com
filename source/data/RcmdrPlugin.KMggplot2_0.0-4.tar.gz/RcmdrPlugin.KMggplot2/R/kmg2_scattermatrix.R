kmg2_scattermatrix <- setRefClass(

  Class = "kmg2_scattermatrix",

  fields = c("top", "buttonsFrame"),

  methods = list(

    plotScattermatrix = function(title=kmg2_gettextRcmdr("Scatter matrix")) {

      # note: The initializeDialog() generates "top"
      initializeDialog(window=top, title=title)

      vbbox1 <- kmg2_variablesbox$new()
      vbbox1$front(
        top       = top, 
        types     = list(Numeric(), Factors()),
        titles    = list(
            kmg2_gettextRcmdr("Select variables (three or more)"),
            kmg2_gettextRcmdr("Stratum variable")
	),
        modes     = list("multiple", "single")
      )

      lbbox1 <- kmg2_labelboxes$new()
      lbbox1$front(
        top        = top,
        initValues = list(""),
        titles     = list(
            kmg2_gettextRcmdr("Title"))
      )

#######################################################

      lbbox2 <- kmg2_labelboxes$new()
      lbbox2$front(
        top        = top,
        initValues = list("png","8","6","100","g1"),
        titles     = list(
            kmg2_gettextRcmdr("File Extensions"),
            kmg2_gettextRcmdr("width"),
            kmg2_gettextRcmdr("height"),
            kmg2_gettextRcmdr("dpi"),
            kmg2_gettextRcmdr("File Name")
		)
      )

#######################################################

      rbbox1 <- kmg2_radioboxes$new()
      rbbox1$front(
        top    = top,
        labels = list(
            kmg2_gettextRcmdr("None"),
            kmg2_gettextRcmdr("Smoothing with C.I. (linear regression)"),
            kmg2_gettextRcmdr("Smoosing without C.I. (linear regression)"),
            kmg2_gettextRcmdr("Smoosing with C.I. (loess or gam)"),
            kmg2_gettextRcmdr("Smoosing without C.I. (loess or gam)")),
        title  = kmg2_gettextRcmdr("Smoosing type")
      )

      tbbox1 <- kmg2_toolbox$new()
      tbbox1$front(top, showcolourbox = FALSE, fontSize = "12")

      onOK <- function() {

        x            <- getSelection(vbbox1$vbvariables[[1]])
        z            <- getSelection(vbbox1$vbvariables[[2]])
        main         <- tclvalue(lbbox1$lbtboxes[[1]]$tvariable)

        smoothType   <- tclvalue(rbbox1$rbvariable)

        fontSize     <- tclvalue(tbbox1$tbfontsizebox$tvariable)
        fontfamily  <- getSelection(tbbox1$tbfontfamilybox)
        saveFile     <- tclvalue(tbbox1$tbcheckbox$cbvariables[[1]])

##################################################################################

        savetype      <- tclvalue(lbbox2$lbtboxes[[1]]$tvariable)
        width         <- tclvalue(lbbox2$lbtboxes[[2]]$tvariable)
        height        <- tclvalue(lbbox2$lbtboxes[[3]]$tvariable)
        dpi           <- tclvalue(lbbox2$lbtboxes[[4]]$tvariable)
	Graphname     <- tclvalue(lbbox2$lbtboxes[[5]]$tvariable)

###################################################################################


        if (tclvalue(tbbox1$tbthemebox$rbvariable) == "1")
          theme <- "theme_bw"
        else if (tclvalue(tbbox1$tbthemebox$rbvariable) == "2")
          theme <- "theme_classic"
        else if (tclvalue(tbbox1$tbthemebox$rbvariable) == "3")
          theme <- "theme_classicL"
        else if (tclvalue(tbbox1$tbthemebox$rbvariable) == "4")
          theme <- "theme_classicR"
        else if (tclvalue(tbbox1$tbthemebox$rbvariable) == "5")
          theme <- "theme_mine"
        else if (tclvalue(tbbox1$tbthemebox$rbvariable) == "6")
          theme <- "theme_mineL"
        else if (tclvalue(tbbox1$tbthemebox$rbvariable) == "7")
          theme <- "theme_mineR"
        else
          theme <- "theme_bw"



        closeDialog()
        if (length(x) < 3) {
          errorCondition(recall=plotScattermatrix, message=kmg2_gettextRcmdr("Fewer than 3 variable selected."))
          return()
        }

        #######################################################################
        if (nchar(main) == 0) {
          main <- ""
        } else {
          main <- paste("labs(title = \"", main, "\") + \n", sep="")
        }

        .activeDataSet <- ActiveDataSet()


      command <- do.call(paste, c(x, list(sep = "\", \"")))
      command <- paste0(".df <- ", ActiveDataSet(), "[c(\"", command, "\")]")
      
      doItAndPrint(command)
      
      command <- paste0(
        ".grid <- expand.grid(x = 1:ncol(.df), y = 1:ncol(.df))\n",
        ".grid <- subset(.grid, x != y)\n",
        ".all <- do.call(\"rbind\", lapply(1:nrow(.grid), function(i) {\n",
        "  xcol <- .grid[i, \"x\"]; \n",
        "  ycol <- .grid[i, \"y\"]; \n",
        "  data.frame(xvar = names(.df)[ycol], yvar = names(.df)[xcol],\n",
        "             x = .df[, xcol], y = .df[, ycol], .df)\n",
        "}))\n",
        ".all$xvar  <- factor(.all$xvar, levels = names(.df))\n",
        ".all$yvar  <- factor(.all$yvar, levels = names(.df))\n",
        ".densities <- do.call(\"rbind\", lapply(1:ncol(.df), function(i) {\n",
        "  .tmp <- as.data.frame(density(x = .df[, i])[c(\"x\", \"y\")]); \n",
        "  .tmp$y <- .tmp$y/max(.tmp$y)*diff(range(.tmp$x)) + min(.tmp$x); \n",
        "  data.frame(xvar = names(.df)[i], yvar = names(.df)[i],\n",
        "            x = .tmp$x, y = .tmp$y)\n",
        "}))"
      )
      doItAndPrint(command)
      
      if (length(z) != 0) {
        command <- paste0(
          ".all <- data.frame(.all, z = rep(",
          ActiveDataSet(), "$", z, ", ",
          "length = nrow(.all)))\n",
          ".densities$z <- NA"
        )
        doItAndPrint(command)
      }
 
      if (length(z) == 0) {
        ggplot <- paste0(
          "ggplot(.all, aes(x = x, y = y)) + \n  ",
          "facet_grid(xvar ~ yvar, scales = \"free\") + \n  ",
          "geom_point() + \n  ",
          "geom_line(aes(x = x, y = y), data = .densities) + \n  "
        )
      } else {
        ggplot <- paste0(
          "ggplot(.all, aes(x = x, y = y, colour = z, shape = z)) + \n  ",
          "facet_grid(xvar ~ yvar, scales = \"free\") + \n  ",
          "geom_point() + \n  ",
          "geom_line(aes(x = x, y = y), data = .densities, colour = \"black\") + \n  "
        )
      }

      if (length(z) == 0) {
        aes <- ""
      } else if (smoothType == "4") {
        aes <- "aes(fill = z)"
      } else {
        aes <- "aes(fill = z), "
      }
      
      if (smoothType == "1") {
        geom <-  ""
      } else if (smoothType == "2") {
        geom <- paste0("stat_smooth(", aes, "method = \"lm\") + \n  ")
      } else if (smoothType == "3") {
        geom <- paste0("stat_smooth(", aes, "method = \"lm\", se = FALSE) + \n  ")
      } else if (smoothType == "4") {
        geom <- paste0("stat_smooth(", aes, ") + \n  ")
      } else if (smoothType == "5") {
        geom <- paste0("stat_smooth(", aes, "se = FALSE) + \n  ")
      }


###################################################################

        command <- paste0(
          ".plot1 <- " ,ggplot,geom,
          main, "theme(legend.position = \"none\") + \n",
          theme, "(", fontSize, ", \"", fontfamily, "\")"
        )
        doItAndPrint(command)

	print(.plot1)

        if (saveFile == "1") {   
   
          command <- paste0("ggsave('",Graphname,".",savetype,"', .plot1 ,width=",width,",height=",height,",dpi=",dpi,")")

          doItAndPrint(command)
        }

        doItAndPrint("rm(.df, .grid , .all , .densities)")
				
        activateMenus()
        tkfocus(CommanderWindow())

      }

      # note: The OKCancelHelp() generates "buttonsFrame"
      OKCancelHelp(helpSubject="stat_smooth")

      vbbox1$back()
      lbbox1$back()
      lbbox2$back()
      rbbox1$back()
      tbbox1$back(4)

      tkgrid(buttonsFrame, stick="nw")
      dialogSuffix()

    }

  )
)

