kmg2_discretebar <- setRefClass(

  Class = "kmg2_discretebar",

  fields = c("top", "buttonsFrame"),

  methods = list(

    plotDiscretebar = function(title=kmg2_gettextRcmdr("Bar chart for discrete variables")) {

      # note: The initializeDialog() generates "top"
      initializeDialog(window=top, title=title)

      vbbox1 <- kmg2_variablesbox$new()
      vbbox1$front(
        top       = top, 
        types     = list(Factors(), Factors()),
        titles    = list(
            kmg2_gettextRcmdr("Variable (pick one)"),
            kmg2_gettextRcmdr("Stratum variable")
		)
      )

      lbbox1 <- kmg2_labelboxes$new()
      lbbox1$front(
        top        = top,
        initValues = list("<auto>", "<auto>", ""),
        titles     = list(
            kmg2_gettextRcmdr("Horizontal axis label"),
            kmg2_gettextRcmdr("Vertical axis label"),
            kmg2_gettextRcmdr("Title"))
      )

#######################################################

      lbbox2 <- kmg2_labelboxes$new()
      lbbox2$front(
        top        = top,
        initValues = list("png","8","6","100","g1"),
        titles     = list(
            kmg2_gettextRcmdr("File Extensions"),
            kmg2_gettextRcmdr("width"),
            kmg2_gettextRcmdr("height"),
            kmg2_gettextRcmdr("dpi"),
            kmg2_gettextRcmdr("File Name")
		)
      )

      rbbox1 <- kmg2_radioboxes$new()
      rbbox1$front(
        top    = top,
        labels = list(
		        kmg2_gettextRcmdr("Frequency counts"),
		        kmg2_gettextRcmdr("Percentages")
	),
        title =  kmg2_gettextRcmdr("Axis scaling")
      )


#######################################################

      tbbox1 <- kmg2_toolbox$new()
      tbbox1$front(top)

      onOK <- function() {

        y            <- getSelection(vbbox1$vbvariables[[1]])
        z            <- getSelection(vbbox1$vbvariables[[2]])

        xlab         <- tclvalue(lbbox1$lbtboxes[[1]]$tvariable)
        ylab         <- tclvalue(lbbox1$lbtboxes[[2]]$tvariable)
        main         <- tclvalue(lbbox1$lbtboxes[[3]]$tvariable)

        fontSize     <- tclvalue(tbbox1$tbfontsizebox$tvariable)
        fontfamily  <- getSelection(tbbox1$tbfontfamilybox)
        colourset    <- getSelection(tbbox1$tbcolourbox)
        saveFile     <- tclvalue(tbbox1$tbcheckbox$cbvariables[[1]])

        axisScaling    <- tclvalue(rbbox1$rbvariable)

      if (axisScaling == "1") {
        yauto  <- "Frequency counts"
      } else {
        yauto  <- "Percent"
      }

##################################################################################

        savetype      <- tclvalue(lbbox2$lbtboxes[[1]]$tvariable)
        width         <- tclvalue(lbbox2$lbtboxes[[2]]$tvariable)
        height        <- tclvalue(lbbox2$lbtboxes[[3]]$tvariable)
        dpi           <- tclvalue(lbbox2$lbtboxes[[4]]$tvariable)
	Graphname     <- tclvalue(lbbox2$lbtboxes[[5]]$tvariable)

###################################################################################


        if (tclvalue(tbbox1$tbthemebox$rbvariable) == "1")
          theme <- "theme_bw"
        else if (tclvalue(tbbox1$tbthemebox$rbvariable) == "2")
          theme <- "theme_classic"
        else if (tclvalue(tbbox1$tbthemebox$rbvariable) == "3")
          theme <- "theme_classicL"
        else if (tclvalue(tbbox1$tbthemebox$rbvariable) == "4")
          theme <- "theme_classicR"
        else if (tclvalue(tbbox1$tbthemebox$rbvariable) == "5")
          theme <- "theme_mine"
        else if (tclvalue(tbbox1$tbthemebox$rbvariable) == "6")
          theme <- "theme_mineL"
        else if (tclvalue(tbbox1$tbthemebox$rbvariable) == "7")
          theme <- "theme_mineR"
        else
          theme <- "theme_bw"



        closeDialog()
        if (length(y) == 0) {
          errorCondition(recall=plotDiscretebar, message=kmg2_gettextRcmdr("No variable selected."))
          return()
        }

        #######################################################################



        if (nchar(xlab) == 0) {
          xlab <- NULL
        } else if (xlab == "<auto>") {
          xlab <-  y
        } else {
          xlab <- xlab
        }
        if (nchar(ylab) == 0) {
          ylab <- NULL
        } else if (ylab == "<auto>") {
          ylab <- yauto
        } else {
          ylab <- ylab
        }
        if (nchar(main) == 0) {
          main <- ""
        } else {
          main <- main
        }


        labs<- paste0("labs(title='",main,"',x='",xlab,"',y='",ylab,"') +\n")


        .activeDataSet <- ActiveDataSet()

        if (length(z) == 0) {
          command <- paste0(
            ".df <- data.frame(",
            "y = ", .activeDataSet,"$",y,")"
          )
        } else {
          command <- paste0(
            ".df <- data.frame(",
            "y = ", .activeDataSet,"$",y,", ",
            "z = ", .activeDataSet,"$",z,")"
          )
        }
        doItAndPrint(command)

      if (axisScaling == "2") {
 		 geom<- "geom_bar(aes(y = ..count.. / sum(..count..))) + \n" 
	} else {
		geom<- "geom_bar() + \n"
	}

      if (axisScaling == "2") {
        scale <- "scale_y_continuous(expand = expansion(mult = c(0, 0.05)), labels = scales::percent_format()) + \n"
      } else {
        scale <- "scale_y_continuous(expand = expansion(mult = c(0, 0.05))) + \n"
      }

		if (length(z) == 0) {
			facet <- ""
		} else {
			facet <- "facet_grid(z ~ .) + \n"
			fontSize <- "14"
		}

        command <- paste0(
          ".plot1 <- ggplot(data = .df, aes(x = y)) + ",
          geom, scale, facet, 
          labs,
          theme, "(", fontSize, ", \"", fontfamily, "\")"
        )
        doItAndPrint(command)

        doItAndPrint("print(.plot1)")

#####################

        if (saveFile == "1") {   
   
          command <- paste0("ggsave('",Graphname,".",savetype,"', .plot1 ,width=",width,",height=",height,",dpi=",dpi,")")

          doItAndPrint(command)
        }

        doItAndPrint("rm(.df)")

########################

        activateMenus()
        tkfocus(CommanderWindow())

      }

      # note: The OKCancelHelp() generates "buttonsFrame"
      OKCancelHelp(helpSubject="geom_bar")

      vbbox1$back()
      rbbox1$back()
      lbbox1$back()
      lbbox2$back()
      tbbox1$back()

      tkgrid(buttonsFrame, stick="nw")
      dialogSuffix()

    }

  )
)

